// BABA IS Y'ALL SOLVER - BLANK TEMPLATE
// Version 1.0
// Code by Milk 


//get imports (NODEJS)
var simjs = require('../js/simulation')					//access the game states and simulation

let possActions = ["space", "right", "up", "left", "down"];

var an_action_set = [];

var counter  = 0;

var currentGamestate = simjs.getGamestate();
var isYouWin = [];

var WinIsSet = true;
var YouIsSet = true;

var playerObject = [];
var winObject = [];

var waitSequence = [];
var solveSequence = [];
var actions = [];

function informationHandler()
{
	//look for winnables
	if(currentGamestate.winnables.length >= 1)
	{
		winObject = currentGamestate.winnables[0];
		WinIsSet = true;
	}
	else
	{
		WinIsSet = false;
	}
	//look for players
	if(currentGamestate.players.length >= 1)
	{
		playerObject = currentGamestate.players[0];
		YouIsSet = true;
	}
	else
	{
		YouIsSet = false;
	}
}

function solution()
{
	//console.time('Execution Time');

	informationHandler();

	if(!WinIsSet || !YouIsSet)
	{
		isYouWin = isYouWinFilter();

		//look for auto movers
		waitSequence = resolveAutoMove();
		//interpreteRules(currentGamestate);
	}

	let playerX = playerObject.x;
	let playerY = playerObject.y;

	let winX = winObject.x;
	let winY = winObject.y;

	difX = winX - playerX;
	difY = winY - playerY;

	actions = pathToWin(difX,difY);

	an_action_set = an_action_set.concat(waitSequence,actions);

	//console.timeEnd('Execution Time');

	return an_action_set;
}

//returns positions of combinations isYou, isWin
//array[ isYou[], isWin[]]
function isYouWinFilter()
{
	var temp = [];

	//every is tile
	for(const element of currentGamestate.is_connectors)
	{
		let entry = [];

		//get to tile connected to the is tile
		entry.push([currentGamestate.obj_map[element.y][element.x].name + currentGamestate.obj_map[element.y+1][element.x].name,currentGamestate.obj_map[element.y][element.x],currentGamestate.obj_map[element.y+1][element.x]]);
		entry.push([currentGamestate.obj_map[element.y][element.x].name + currentGamestate.obj_map[element.y][element.x+1].name,currentGamestate.obj_map[element.y][element.x],currentGamestate.obj_map[element.y][element.x+1]]);

		//saves the possible connection for the is tile
		temp.push(entry);
	}

	//positions of is you combination
	let isYou = [];

	//position of is win combination
	let isWin = [];

	for(const element of temp)
	{
		if(element[0] == "isyou")
		{
			isYou.push([element[1].x,element[1].y]);
		}
		if(element[0] == "iswin")
		{
			isYou.push([element[1].x,element[1].y]);
		}
	}

	var output = [isYou,isWin];


	/*
	if(counter < 1)
	{

	
	let print = JSON.stringify([currentGamestate.orig_map,output]);


	const fs = require('fs');
	fs.appendFile("../../output", print, (err) => {
      
    // In case of a error throw err.
    if (err) throw err;
	});

	counter += 1;
	}
	*/

	return output;
}



function resolveAutoMove()
{
	//automovers on the map
	var movers = currentGamestate.auto_movers;

	var pairsObjectiveMovers = [];

	if(movers.length < 1)
	{
		return [];
	}

	//search for combinations of automovers on the same height as isYou combinations
	for (const mover of movers)
	{
		for(const objective of isYouWin[0])
		{
			if(mover.y == objective[1])
			{
				//safe height plus x coordinates of the automover and is
				pairsObjectiveMovers.push([mover.y, mover.x, objective[0], mover.dir]);
			}
		}
	}

	var dist = 0;

	//looking for obj for completion on the the way
	for(const pair in pairsObjectiveMovers)
	{
		for(const obj in currentGamestate.obj_map[pair[0]])
		{	
			//obj hast to be between automover and is connector
			if(obj != undefined && obj.x < pair[1])
			{
				//distance is one lower because field is occupied
				dist = (pair[2] - pair[1])-1;

				//distance has to be reduced by because of pushable block
				if(pair[3] == "right")
				{
					dist -= 1;
				}
			}
		}
	}

	let output = [];

	for(let i = 0; i < dist; i += 1)
	{
		ouput.push("space");
	}
	
	/*
	if(counter < 1)
	{

	
	let print = JSON.stringify(currentGamestate.auto_movers);


	const fs = require('fs');
	fs.appendFile("../../autoMover", print, (err) => {
      
    // In case of a error throw err.
    if (err) throw err;
	});

	counter += 1;
	}
	*/

	return output;
}

function pathToWin(x,y)
{
	let path = [];
	for(let i = 0; i < Math.abs(x); i +=1)
	{
		if(x < 0)
		{
			path.push("left");
		}
		else
		{
			path.push("right");
		}
	}
	
	for(let i = 0; i < Math.abs(y); i += 1)
	{
		if(y < 0)
		{
			path.push("up");
		}
		else
		{
			path.push("down");
		}
	}	

	return path;
}

// NEXT ITERATION STEP FOR SOLVING
function iterSolve(init_state)
{
	// PERFORM ITERATIVE CALCULATIONS HERE //

	/*if(counter < 1)
	{
		let output = simjs.getGamestate();
		//console.log(output);

	
	const fs = require('fs');
	fs.appendFile("../../debugDump", JSON.stringify(output), (err) => {
      
    // In case of a error throw err.
    if (err) throw err;
});

	counter += 1;
	}
	*/

	//return a sequence of actions or empty list
	return solution();
}



// VISIBLE FUNCTION FOR OTHER JS FILES (NODEJS)
module.exports = {
	step : function(init_state){return iterSolve(init_state)},		// iterative step function (returns solution as list of steps from poss_actions or empty list)
	init : function(init_state){},									// initializing function here
	best_sol : function(){return an_action_set;}
}


